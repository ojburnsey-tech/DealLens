# `notebooks/01_data_quality.ipynb`

> Converted from the current Jupyter notebook. Cell order and source are preserved.

## Cell 1 — markdown

# Data quality

This notebook calls reusable DealLens services. Financial statistics include only VERIFIED records that pass publication QA. DRAFT records remain outside the analytical sample. An empty sample is an unavailable analysis, not a zero-valued valuation.

Currency, FY/LTM periods, earnings definitions and premium reference bases stay in separate cohorts. Every displayed chart identifies its metric, unit, sample size and basis. Results are descriptive and do not establish causation.

## Cell 2 — code

```python
from deallens.notebook_support import (load_inventory, data_quality_summary)
records = load_inventory()
print(data_quality_summary(records))
```

## Cell 3 — code

```python
quality = data_quality_summary(records)
quality
```

## Cell 4 — markdown

## Analyst interpretation

No owner interpretation has been supplied. Review sample coverage, missing fields and the source records before drawing conclusions. No inference is made from an empty or unverified sample.
