# `notebooks/04_synergy_analysis.ipynb`

> Converted from the current Jupyter notebook. Cell order and source are preserved.

## Cell 1 — markdown

# Synergy analysis

This notebook calls reusable DealLens services. Financial statistics include only VERIFIED records that pass publication QA. DRAFT records remain outside the analytical sample. An empty sample is an unavailable analysis, not a zero-valued valuation.

Currency, FY/LTM periods, earnings definitions and premium reference bases stay in separate cohorts. Every displayed chart identifies its metric, unit, sample size and basis. Results are descriptive and do not establish causation.

## Cell 2 — code

```python
from deallens.notebook_support import (load_inventory, data_quality_summary, metric_summary, metric_charts)
records = load_inventory()
print(data_quality_summary(records))
```

## Cell 3 — code

```python
metric_summary(records, 'cost_synergy_ev', group_by='sector')
```

## Cell 4 — code

```python
for metric in ('cost_synergy_ev', 'cost_synergy_ebitda', 'synergy_adjusted_multiple'):
    metric_charts(metric_summary(records, metric))
```

## Cell 5 — markdown

## Analyst interpretation

No owner interpretation has been supplied. Review sample coverage, missing fields and the source records before drawing conclusions. No inference is made from an empty or unverified sample.
