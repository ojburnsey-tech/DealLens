# `notebooks/05_financing_and_leverage.ipynb`

> Converted from the current Jupyter notebook. Cell order and source are preserved.

## Cell 1 — markdown

# Financing and leverage

This notebook calls reusable DealLens services. Financial statistics include only VERIFIED records that pass publication QA. DRAFT records remain outside the analytical sample. An empty sample is an unavailable analysis, not a zero-valued valuation.

Currency, FY/LTM periods, earnings definitions and premium reference bases stay in separate cohorts. Every displayed chart identifies its metric, unit, sample size and basis. Results are descriptive and do not establish causation.

## Cell 2 — code

```python
from deallens.notebook_support import (load_inventory, data_quality_summary, metric_summary, metric_charts)
records = load_inventory()
print(data_quality_summary(records))
```

## Cell 3 — code

```python
data_quality_summary(records)['availability']
```

## Cell 4 — code

```python
for metric in ('buyer_standalone_leverage', 'leverage_before_synergy', 'leverage_after_synergy'):
    metric_charts(metric_summary(records, metric))
```

## Cell 5 — markdown

## Analyst interpretation

No owner interpretation has been supplied. Review sample coverage, missing fields and the source records before drawing conclusions. No inference is made from an empty or unverified sample.
