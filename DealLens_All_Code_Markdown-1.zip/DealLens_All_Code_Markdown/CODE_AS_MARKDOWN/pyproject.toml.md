# `pyproject.toml`

> Complete snapshot of `pyproject.toml`.

```toml
[build-system]
requires = ["setuptools>=75"]
build-backend = "setuptools.build_meta"

[project]
name = "deallens"
version = "0.1.0"
description = "Source-auditable UK and European transaction research"
requires-python = ">=3.12"
dependencies = ["duckdb>=1.1,<2", "pydantic>=2.9,<3", "PyYAML>=6,<7", "httpx>=0.27,<1", "reportlab>=4.2,<5"]

[project.optional-dependencies]
dev = ["pytest>=8,<10", "ruff>=0.9,<1", "mypy>=1.15,<3", "types-PyYAML>=6,<7", "types-reportlab>=4,<5", "pytest-cov>=6,<8", "pypdf>=5,<7", "pip-audit>=2.9,<3"]

notebooks = ["nbformat>=5.10,<6", "nbclient>=0.10,<1", "ipykernel>=6,<8", "matplotlib>=3.9,<4"]

[project.scripts]
deallens = "deallens.cli:main"

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
pythonpath = ["src"]
testpaths = ["tests"]

[tool.ruff]
line-length = 110

[tool.ruff.lint]
select = ["E4", "E7", "E9", "F"]
```
