# `src/deallens.egg-info/SOURCES.txt`

> Complete snapshot of `src/deallens.egg-info/SOURCES.txt`.

```text
README.md
pyproject.toml
src/deallens/__init__.py
src/deallens/__main__.py
src/deallens/analytics.py
src/deallens/cli.py
src/deallens/companies_house.py
src/deallens/finance.py
src/deallens/models.py
src/deallens/notebook_support.py
src/deallens/precedents.py
src/deallens/qa.py
src/deallens/releases.py
src/deallens/reports.py
src/deallens/research.py
src/deallens/store.py
src/deallens.egg-info/PKG-INFO
src/deallens.egg-info/SOURCES.txt
src/deallens.egg-info/dependency_links.txt
src/deallens.egg-info/entry_points.txt
src/deallens.egg-info/requires.txt
src/deallens.egg-info/top_level.txt
tests/test_analytics_precedents.py
tests/test_companies_house.py
tests/test_finance.py
tests/test_finance_review_regressions.py
tests/test_gold_standard.py
tests/test_qa.py
tests/test_releases.py
tests/test_research.py
```
