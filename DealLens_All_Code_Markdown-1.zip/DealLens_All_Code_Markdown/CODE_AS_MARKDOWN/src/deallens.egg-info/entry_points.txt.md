# `src/deallens.egg-info/entry_points.txt`

> Complete snapshot of `src/deallens.egg-info/entry_points.txt`.

```text
[console_scripts]
deallens = deallens.cli:main
```
