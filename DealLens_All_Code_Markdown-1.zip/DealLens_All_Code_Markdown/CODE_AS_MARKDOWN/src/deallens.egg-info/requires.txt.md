# `src/deallens.egg-info/requires.txt`

> Complete snapshot of `src/deallens.egg-info/requires.txt`.

```text
duckdb<2,>=1.1
pydantic<3,>=2.9
PyYAML<7,>=6
httpx<1,>=0.27
reportlab<5,>=4.2

[dev]
pytest<10,>=8
ruff<1,>=0.9
mypy<3,>=1.15
types-PyYAML<7,>=6
pytest-cov<8,>=6
pypdf<7,>=5
pip-audit<3,>=2.9

[notebooks]
nbformat<6,>=5.10
nbclient<1,>=0.10
ipykernel<8,>=6
matplotlib<4,>=3.9
```
