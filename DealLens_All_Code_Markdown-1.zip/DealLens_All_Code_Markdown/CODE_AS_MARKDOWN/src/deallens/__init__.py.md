# `src/deallens/__init__.py`

> Complete snapshot of `src/deallens/__init__.py`.

```python
"""DealLens: explicit assumptions, reproducible calculations, preserved evidence."""
```
