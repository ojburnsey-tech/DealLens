# `src/deallens/__main__.py`

> Complete snapshot of `src/deallens/__main__.py`.

```python
from .cli import main

raise SystemExit(main())
```
