# DealLens code archive

- Created: 2026-09-24T21:33:12+00:00
- Repository commit at packaging time: `3b5e377d3fbcafe2112174f8a8ce7f98af6df477`
- Files included: 57
- `CODE_AS_MARKDOWN/` contains one Markdown file per project file/component.
- `ORIGINAL_PROJECT/` contains the same current files in their native formats.
- Git metadata, virtual environments, caches, generated build outputs and secrets are excluded.

## Working-tree state at packaging time

```text
 M pyproject.toml
 M src/deallens/cli.py
 M src/deallens/store.py
?? docs/RELEASE_EXPORT_REVIEW.md
?? docs/report_generator.md
?? src/deallens/releases.py
?? src/deallens/reports.py
?? tests/test_releases.py
?? tests/test_reports.py
```

## Validation note

- Ruff lint completed successfully immediately before packaging.
- The saved virtual environment was non-portable in this workspace and was removed by the package runner while attempting an offline rebuild.
- The current dependency set could not be restored offline because `duckdb` was unavailable in the local package cache, so tests and mypy were not rerun during this packaging pass.
- The most recent recorded full check from the preceding work session reported 425 passing tests and 90.32% coverage; treat that as historical, not a fresh result for this ZIP.

## File index

| Original path | Markdown copy | Bytes | SHA-256 |
|---|---|---:|---|
| `README.md` | `README.md.md` | 80593 | `83240e47f02631933b40c3337d8d1f376f9b3300de6ddd40e26bbc1a36df73df` |
| `docs/ANALYTICS_REVIEW.md` | `docs/ANALYTICS_REVIEW.md.md` | 10210 | `347ab481fdcdfcfb55ad3c6947c75512ba9bd13f856fc7e45e600fd3e69f8a09` |
| `docs/PROGRESS.md` | `docs/PROGRESS.md.md` | 5183 | `4b2c1f174e6d27f0a640b4504544e356fab8434ba94d0a715579f3e3a5c3aeca` |
| `docs/RELEASE_EXPORT_REVIEW.md` | `docs/RELEASE_EXPORT_REVIEW.md.md` | 7482 | `a80e2548f3a6763393c55673862117d29974e49b7ef3419150014370cc463428` |
| `docs/STEP20_REVIEW.md` | `docs/STEP20_REVIEW.md.md` | 7896 | `a9e32ea598652763ea50ecf6ec224073dfef2a2ff9819e53ebb91ebf8ba3421e` |
| `docs/analytics.md` | `docs/analytics.md.md` | 3756 | `7dd8a19ac3495d9e285435e64d55cd85fe3b4b6157c32e6b691320d460af7c4c` |
| `docs/companies_house.md` | `docs/companies_house.md.md` | 2731 | `b73159bcd1c8e2ed1bb3db1a982a8aa39ef834b833c59d9b755f0687dce6de55` |
| `docs/completion_audit.md` | `docs/completion_audit.md.md` | 5959 | `77ea8bfd807c621c85b0a7b6442847becd5a1edfe797ffd8115f4fcab1df1a6e` |
| `docs/finance_methodology.md` | `docs/finance_methodology.md.md` | 7278 | `47e9343003125aa6396b29516c63d5746fd8a4bea7a2a7dc00066ac1c67a4d7f` |
| `docs/gold_standard_validation.md` | `docs/gold_standard_validation.md.md` | 4907 | `db64e5e439c243e763247c4f2f57f78f8d1a63fc7aee5fa3f762bd0d159231a2` |
| `docs/implementation_checklist.md` | `docs/implementation_checklist.md.md` | 5121 | `07479f1dafc086eed356c640ccec04095b4485dc2e424ee9e4faa2f6f857d88e` |
| `docs/qa_policy.md` | `docs/qa_policy.md.md` | 1998 | `c710004980bce7255cf3af8c522df0608be66e085a0c4e0ee903d63bb8d77b7c` |
| `docs/report_generator.md` | `docs/report_generator.md.md` | 2453 | `3bbfb8bc3a56eeb56384469b83ca7b11dddc5551aa555c799991cdf1f6a47bba` |
| `notebooks/01_data_quality.ipynb` | `notebooks/01_data_quality.ipynb.md` | 1763 | `32af27b91befb7b988eb144762d8b831e0f77a8f21300e640e50b29923c1ac01` |
| `notebooks/02_valuation_overview.ipynb` | `notebooks/02_valuation_overview.ipynb.md` | 2134 | `5603f0ce1c925ed99b767a2dce90dc9bb582436e2c10fc4d1c8d77e6da1a3934` |
| `notebooks/03_takeover_premiums.ipynb` | `notebooks/03_takeover_premiums.ipynb.md` | 2025 | `2e0e9a2dcbfa6ef3c72b80fb3b3b88e359c25bae3ecf424eb81b2305de29deb0` |
| `notebooks/04_synergy_analysis.ipynb` | `notebooks/04_synergy_analysis.ipynb.md` | 2124 | `33540eca8e3fb60d3275d8141de018e08e92b90a9bbf5585baf55ef8fa6551b3` |
| `notebooks/05_financing_and_leverage.ipynb` | `notebooks/05_financing_and_leverage.ipynb.md` | 2155 | `4b2d428ca9fc16347e009b995bc9cef41cd5ee0154f86d5933e8640210fc2f3e` |
| `notebooks/06_deal_outcomes.ipynb` | `notebooks/06_deal_outcomes.ipynb.md` | 2026 | `3e5a07d17b9bc3e15a2792437cfd4f8928e35618c98c8d3b4e1f195512487469` |
| `pyproject.toml` | `pyproject.toml.md` | 879 | `402fa3ef50992fb989ea7008816e1a5c175997447d703ee5e8433eae4c37d03c` |
| `research/inbox/DL-00001.yml` | `research/inbox/DL-00001.yml.md` | 34738 | `835ea28f8cd1f535b09078d7c8b7cb48d68c71cacf08a87e186755f589516153` |
| `research/inbox/DL-00001_REVIEW.md` | `research/inbox/DL-00001_REVIEW.md.md` | 7969 | `a95bab93e75c84b51d8c1873ab18fee4f0ec6f88a7582aac2ffaddc1f8bc8b82` |
| `research/templates/README.md` | `research/templates/README.md.md` | 7364 | `8b3f136f16869f8ca241858213ad409363dd92f72f03c2c204de3e6220bbb820` |
| `research/templates/deal.yml` | `research/templates/deal.yml.md` | 2197 | `6b9d695dfced32f9eea9e7a5ecfbe7fc2534923433fe082e7444609ad45503cd` |
| `research/verified/README.md` | `research/verified/README.md.md` | 264 | `bf0b7689a1560fd35462a34439d9595a107f06926814b9a0d1cebf4b0f2b390d` |
| `scripts/check_notebooks.py` | `scripts/check_notebooks.py.md` | 1236 | `ffb2c665abb56339ec3688dae4761c6249424ff8e4b1325509e576a6b8bab9d5` |
| `src/deallens.egg-info/PKG-INFO` | `src/deallens.egg-info/PKG-INFO.md` | 881 | `22e4e9ff60454a55d05f0eccb7dc45dce6d58f05b07b65dc81a243a92a60ff81` |
| `src/deallens.egg-info/SOURCES.txt` | `src/deallens.egg-info/SOURCES.txt.md` | 811 | `28d290a4530a62e5b7c9f3acec16b63fce3df8122e1b90e055ad33bdbf4dedec` |
| `src/deallens.egg-info/dependency_links.txt` | `src/deallens.egg-info/dependency_links.txt.md` | 1 | `01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b` |
| `src/deallens.egg-info/entry_points.txt` | `src/deallens.egg-info/entry_points.txt.md` | 47 | `61845425229803a6068f0d307225a860e3e93b83c13833e4be9210d80aaf0a7c` |
| `src/deallens.egg-info/requires.txt` | `src/deallens.egg-info/requires.txt.md` | 276 | `03f6272f1ed6a3ce8e8d41723792be9655eec999ba0c51b0786f6afebf301308` |
| `src/deallens.egg-info/top_level.txt` | `src/deallens.egg-info/top_level.txt.md` | 9 | `c27031c7b6375da1bf644c9260f26b9d59381c836c2686c5601dac2e462f088f` |
| `src/deallens/__init__.py` | `src/deallens/__init__.py.md` | 85 | `3c4e2ad3738f289d36e6443dfb76dc7d767976e625c7e7a26decccd76a879887` |
| `src/deallens/__main__.py` | `src/deallens/__main__.py.md` | 48 | `935a1c1166b0c1ea35a82256345000bf2c73ded718d77773bc27a71ecce28f7d` |
| `src/deallens/analytics.py` | `src/deallens/analytics.py.md` | 11035 | `62f9e62cc3e290427cad12c038b29b80b4f53ac98ad76b4f50e4f3b5034112cd` |
| `src/deallens/cli.py` | `src/deallens/cli.py.md` | 6769 | `9f765787d3af4f5d791a37f304ec19d0a776ce345aa47eeb387b6ce014095981` |
| `src/deallens/companies_house.py` | `src/deallens/companies_house.py.md` | 9009 | `a9c970c0cd45675fcf36d8908d8c329155bc1229f4a8e65f492d805dbb95fdfb` |
| `src/deallens/finance.py` | `src/deallens/finance.py.md` | 31747 | `e7b8b768f5f18c46968e471bf80ba2eef655d91bfdab971f72bd9a2a8f6238a1` |
| `src/deallens/models.py` | `src/deallens/models.py.md` | 5419 | `8ea7c736794eced3255b8b3e2bbcbcfad51536b727ddee45a48d5fc19e10bcfc` |
| `src/deallens/notebook_support.py` | `src/deallens/notebook_support.py.md` | 3002 | `45f956d893e94278e80179d8e222c9bed9818a9fd070b8305ea706891c01daf3` |
| `src/deallens/precedents.py` | `src/deallens/precedents.py.md` | 9190 | `09e0f3fde6609faf5cefb993b638f20f51c563549dbd1f6cb3eb980db8d578ee` |
| `src/deallens/qa.py` | `src/deallens/qa.py.md` | 8111 | `93a47a553b41e252d5b2cdcf700447422551d49d34f8662e0d83edabbb5dbe93` |
| `src/deallens/releases.py` | `src/deallens/releases.py.md` | 14341 | `38fff6b4c9d90a9a9b9a8d13410226b3b74133272503f834e5f65c57c36be485` |
| `src/deallens/reports.py` | `src/deallens/reports.py.md` | 13906 | `1701d3d448393f64d3e4a350d8e4e959d0779f8d15dd2f442ad21e2049456990` |
| `src/deallens/research.py` | `src/deallens/research.py.md` | 17403 | `45dcd1ad758843e21f9a311ebfc91f7fb6b716f0aec4e631bda8bf6e1bb6a518` |
| `src/deallens/store.py` | `src/deallens/store.py.md` | 6433 | `0c98aa72b43f142a43fb05476b0638626ad38aeed3370fa3814f487a3bf979ea` |
| `tests/README.md` | `tests/README.md.md` | 1136 | `83409a99d1b1eb8ef2fa4fd8558cdb3ac8e1598d7a34e7092623c0e95445466a` |
| `tests/conftest.py` | `tests/conftest.py.md` | 958 | `538ce03bffea7064c01d47d2281693932a65444b99e81993a5c009f869d8ca0c` |
| `tests/test_analytics_precedents.py` | `tests/test_analytics_precedents.py.md` | 17362 | `20dddc483ac257c2d1973dd877dc215fe067e7e28261ecf5efaea5ba37e1cc0b` |
| `tests/test_companies_house.py` | `tests/test_companies_house.py.md` | 8741 | `f2bd8d8a8c8b6aba0786a1e12243d39a280cf41ea55fdf3dcdddcf1f0491aac7` |
| `tests/test_finance.py` | `tests/test_finance.py.md` | 15761 | `db8bbcac0f52e7c7c2ddbcc937f359059fbb3f5b17024f7d6364accc503eb69a` |
| `tests/test_finance_review_regressions.py` | `tests/test_finance_review_regressions.py.md` | 17215 | `746b37e858b7b5400538a646373b5770be12849f921ccd2fe05ee01ebc000c3d` |
| `tests/test_gold_standard.py` | `tests/test_gold_standard.py.md` | 8239 | `a11b3e5537a1a579e758a946dba450db6e83f4f142a873a7b2e73d5baa483323` |
| `tests/test_qa.py` | `tests/test_qa.py.md` | 6411 | `434b6f6ea518aebaa0b5a47ab2fad015cabdc699a3b36676c5b204929b5f1c96` |
| `tests/test_releases.py` | `tests/test_releases.py.md` | 9307 | `1ecc8f3775ede2cf8c01bf6ce899a87927b665fffe9de795b650d34cf473419e` |
| `tests/test_reports.py` | `tests/test_reports.py.md` | 3458 | `cf9acc793b521c617cbb82fd83162511c1aee36d25ca3e4e7c63069260f416ae` |
| `tests/test_research.py` | `tests/test_research.py.md` | 4688 | `e800d145ec9c05a024d2ac0e5eef48e85d7c79d5c421512418a2837b3ee8b49c` |
